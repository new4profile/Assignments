//package com.example.user_service.controller;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.example.user_service.client.BankAcountServiceClient;
//import com.example.user_service.dto.BankAccountDTO;
//import com.example.user_service.dto.UserDTO;
//import com.example.user_service.entity.User;
//import com.example.user_service.repo.UserRepository;
//
//@RestController
//@RequestMapping("/user")
//public class UserController {
//	
//	@Autowired
//    private UserRepository userRepository;
//	
//	@Autowired
//    private BankAcountServiceClient bankAcountServiceClient;
//	
//	@PostMapping
//    public UserDTO createUser(@RequestBody UserDTO userDTO) {
//        User user = new User();
//        user.setName(userDTO.getName());
//        user.setAddress(userDTO.getAddress());
//        User savedUser = userRepository.save(user);
//
//        userDTO.setId(savedUser.getId());
//        for (BankAccountDTO accountDTO : userDTO.getListBankAccounts()) {
//            accountDTO.setUserId(savedUser.getId());
//            bankAcountServiceClient.createAccount(accountDTO);
//        }
//
//        return userDTO;
//    }
//	
//	@GetMapping("/{id}")
//    public UserDTO getUser(@PathVariable int id) {
//        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
//        List<BankAccountDTO> accounts = bankAcountServiceClient.getAccountsByUserId(id);
//
//        UserDTO userDTO = new UserDTO();
//        userDTO.setId(user.getId());
//        userDTO.setName(user.getName());
//        userDTO.setAddress(user.getAddress());
//        userDTO.setListBankAccounts(accounts);
//        return userDTO;
//    }
//	
//	
////	@PostMapping
////	public User saveUserData(@RequestBody User user) {
////		User saveData = userService.saveUser(user);
////		System.out.println(saveData);
////		return saveData;
////	}
////	
////	@GetMapping
////	public List<User> getAllUserData(){
////		List<User> allUsersData = userService.getAllUsers();
////		return allUsersData;
////	}
////	
////	@GetMapping("/{id}")
////	public Optional<User> getUserDataByID(@PathVariable int id) {
////		Optional<User> userDataById = userService.getUserById(id);
////		return userDataById;
////	}
////	
////	@PutMapping("/{id}")
////	public User updateUserDataById(@PathVariable int id, @RequestBody User user) {
////		User updateUserDataById = userService.updateUserById(id, user);
////		return updateUserDataById;
////	}
////	
////	@DeleteMapping("/{id}")
////	public void deleteUserDataById(@PathVariable int id) {
////		userService.deleteUserById(id);
////	}
//}
