package com.example.user_service.service;

import java.util.List;
import java.util.Optional;

import com.example.user_service.dto.UserDTO;
import com.example.user_service.entity.User;

public interface UserService {
	
	User saveUser(User user);
    List<User> getAllUsers();
    Optional<User> getUserById(int id);
    User updateUserById(int id, User user);
    void deleteUserById(int id);
	
	//UserDTO saveUser(UserDTO userDTO);
//    List<UserDTO> getAllUsers();
//    Optional<UserDTO> getUserById(int id);
//    UserDTO updateUserById(int id, UserDTO userDTO);
//    void deleteUserById(int id);
}