//package com.example.user_service.service;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;
//
//import com.example.user_service.dto.BankAccountDTO;
//import com.example.user_service.entity.User;
//import com.example.user_service.repo.UserRepository;
//
//@Service
//public class UserServiceImpl implements UserService{
//	
//	@Autowired
//	private UserRepository userRepository;
//	
//	@Autowired
//	private RestTemplate restTemplate;
//	
//	//private String bankAccountUrl = "http://localhost:8082/api/bankaccount";
//	
//	@Override
//	public User saveUser(User user) {
//		// Save the user data in the User DB
//		User saveUser = userRepository.save(user);
//		
//		// Get the ID of the saved user
//        int userId = saveUser.getId();
//        
//        // Create BankAccountDTO object
//        BankAccountDTO bankAccountDTO = new BankAccountDTO(
//                "WB102554", // Replace with actual account number logic
//                "savings", // Example account type
//                userId
//        );
//        
//        // Save the bank account data using RestTemplate
//        String bankAccountServiceUrl = "http://localhost:8082/api/bankaccount";
//        restTemplate.postForObject(bankAccountServiceUrl, bankAccountDTO, BankAccountDTO.class);
//
//        return saveUser;
//	}
//	
////	@Override
////	public UserDTO saveUser(UserDTO userDTO) {
////		User user = new User();
////		user.setName(userDTO.getName());
////		user.setAddress(userDTO.getAddress());
////		userRepository.save(user);
////		
////		for(BankAccountDTO bankAccountDTO : userDTO.getListBankAccounts()) {
////			bankAccountDTO.setUserId(userDTO.getId());
////			restTemplate.postForObject(bankAccountUrl, bankAccountDTO, BankAccountDTO.class);
////		}
////		return userDTO;
////	}
//
//	@Override
//	public List<User> getAllUsers() {
//		List<User> findAllUser = userRepository.findAll();
//		return findAllUser;
//	}
//
//	@Override
//	public Optional<User> getUserById(int id) {
////		Optional<User> findUserById = userRepository.findById(id);
////		if (findUserById != null) {
////            // Fetch associated bank accounts using RestTemplate
////            String url = bankAccountUrl + "/user/" + id;
////            BankAccountDTO[] bankAccounts = restTemplate.getForObject(url, BankAccountDTO[].class);
////            //user.setBankAccounts(List.of(bankAccounts));
////            
////        }
////		return findUserById;
//		
//		Optional<User> findByUserId = userRepository.findById(id);
//		return findByUserId;
//	}
//
//	@Override
//	public User updateUserById(int id, User user) {
//		Optional<User> existUser = userRepository.findById(id);
//		if(existUser.isPresent()) {
//			User updateUser = existUser.get();
//			updateUser.setName(user.getName());
//			updateUser.setAddress(user.getAddress());
//			return userRepository.save(updateUser);
//		}
//		return null;
//	}
//
//	@Override
//	public void deleteUserById(int id) {
//		userRepository.deleteById(id);
//	}
//
//}
