package com.example.user_service.dto;

import java.util.List;

public class UserDTO {
	
	private int id;
    private String name;
    private String address;
    private List<BankAccountDTO> listBankAccounts;
    
	public UserDTO() {
		super();
	}

	public UserDTO(int id, String name, String address, List<BankAccountDTO> listBankAccounts) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.listBankAccounts = listBankAccounts;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<BankAccountDTO> getListBankAccounts() {
		return listBankAccounts;
	}

	public void setListBankAccounts(List<BankAccountDTO> listBankAccounts) {
		this.listBankAccounts = listBankAccounts;
	}

	@Override
	public String toString() {
		return "UserDTO [id=" + id + ", name=" + name + ", address=" + address + ", listBankAccounts="
				+ listBankAccounts + "]";
	}
}
