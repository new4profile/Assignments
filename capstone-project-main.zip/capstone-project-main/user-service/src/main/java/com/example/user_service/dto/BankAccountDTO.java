package com.example.user_service.dto;

public class BankAccountDTO {
	
	private int id;
    private String accountNumber;
    private String accountType;
    private int userId;
    
	public BankAccountDTO() {
		super();
	}
	
	public BankAccountDTO(int id, String accountNumber, String accountType, int userId) {
		super();
		this.id = id;
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.userId = userId;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	@Override
	public String toString() {
		return "BankAccountDTO [id=" + id + ", accountNumber=" + accountNumber + ", accountType=" + accountType
				+ ", userId=" + userId + "]";
	}
}
