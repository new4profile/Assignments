//package com.example.user_service.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import com.example.user_service.client.BankAcountServiceClient;
//
//@Configuration
//public class FeignClientConfig {
//	
//	@Bean
//    public BankAcountServiceClient bankAcountServiceClient() {
//		return null;
//        // Configuration or creation of the BankAcountServiceClient
//        //return new BankAcountServiceClient();  // Make sure it returns the correct type
//    }
//}
