package com.example.bank_account_service.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.bank_account_service.entity.BankAccount;
import com.example.bank_account_service.repo.BankAccountRepo;
import com.example.bank_account_service.service.BankAccountService;

@RestController
@RequestMapping("/bank")
public class BankAccountController {

	@Autowired
	private BankAccountService bankAccountService;
	
	// http://localhost:8082/bankaccount
	// "accountNumber": "WB1002536",
	// "accountType": "Savings",
	// "userId": 1
	@PostMapping
	public BankAccount saveBankAccountData(@RequestBody BankAccount bankAccount) {
		BankAccount saveBankAccountData = bankAccountService.saveBankAccount(bankAccount);
		return saveBankAccountData;
	}

	// http://localhost:8082/bankaccount
	@GetMapping()
	public List<BankAccount> getAllBankAccountData(){
		List<BankAccount> allBankAccountData = bankAccountService.getAllBankAccount();
		return allBankAccountData;
	}
	
	// http://localhost:8082/bankaccount/{id}
	@GetMapping("/{id}")
	public Optional<BankAccount> getBankAccountDataById(@PathVariable int id) {
		Optional<BankAccount> bankAccountDataById = bankAccountService.getBankAccountById(id);
		return bankAccountDataById;
	}
	
	// http://localhost:8082/bankaccount/{id}
	@PutMapping("/{id}")
	public BankAccount updateBankAccountData(@PathVariable int id, @RequestBody BankAccount bankAccount) {
		BankAccount updateBankAccountDataById = bankAccountService.updateBankAccountById(id, bankAccount);
		return updateBankAccountDataById;
	}
	
	// http://localhost:8082/bankaccount/{id}
	@DeleteMapping("/{id}")
	public void deleteBankAccountDataById(@PathVariable int id) {
		bankAccountService.deleteBankAccountById(id);
	}
	
	@GetMapping("/user/{userId}")
	public List<BankAccount> getBankAccountByUserId(@PathVariable int userId){
		List<BankAccount> byUserId = bankAccountService.findByUserId(userId);
		return byUserId;
	}
}
