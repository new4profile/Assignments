package com.example.bank_account_service.service;

import java.util.List;
import java.util.Optional;

import com.example.bank_account_service.entity.BankAccount;


public interface BankAccountService {
	
	BankAccount saveBankAccount(BankAccount bankAccount);
    List<BankAccount> getAllBankAccount();
    Optional<BankAccount> getBankAccountById(int id);
    BankAccount updateBankAccountById(int id, BankAccount bankAccount);
    void deleteBankAccountById(int id);
    
    List<BankAccount> findByUserId(int userId);  // Find accounts by User ID
}
