package com.example.bank_account_service.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.bank_account_service.entity.BankAccount;
import com.example.bank_account_service.repo.BankAccountRepo;

@Service
public class BankAccountServiceImpl implements BankAccountService{

	@Autowired
	private BankAccountRepo bankAccountRepo;
	
	@Override
	public BankAccount saveBankAccount(BankAccount bankAccount) {
		BankAccount saveBankAccount = bankAccountRepo.save(bankAccount);
		return saveBankAccount;
	}

	@Override
	public List<BankAccount> getAllBankAccount() {
		List<BankAccount> findAllBankAccount = bankAccountRepo.findAll();
		return findAllBankAccount;
	}

	@Override
	public Optional<BankAccount> getBankAccountById(int id) {
		Optional<BankAccount> findByBankAccountId = bankAccountRepo.findById(id);
		return findByBankAccountId;
	}

	@Override
	public BankAccount updateBankAccountById(int id, BankAccount bankAccount) {
		Optional<BankAccount> existBankAccount = bankAccountRepo.findById(id);
		if(existBankAccount.isPresent()) {
			BankAccount updateBankAccount = existBankAccount.get();
			updateBankAccount.setAccountNumber(bankAccount.getAccountNumber());
			updateBankAccount.setAccountType(bankAccount.getAccountType());
			updateBankAccount.setUserId(bankAccount.getUserId());
			return bankAccountRepo.save(updateBankAccount);
		}
		return null;
	}

	@Override
	public void deleteBankAccountById(int id) {
		bankAccountRepo.deleteById(id);
	}

	@Override
	public List<BankAccount> findByUserId(int userId) {
		List<BankAccount> findByUserId = bankAccountRepo.findByUserId(userId);
		return findByUserId;
	}

}
