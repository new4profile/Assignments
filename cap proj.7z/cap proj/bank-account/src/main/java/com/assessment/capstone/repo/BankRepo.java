package com.assessment.capstone.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.assessment.capstone.entity.BankAccount;

public interface BankRepo extends JpaRepository<BankAccount, Integer> {

}
