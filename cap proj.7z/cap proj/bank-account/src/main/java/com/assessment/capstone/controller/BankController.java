package com.assessment.capstone.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assessment.capstone.entity.BankAccount;
import com.assessment.capstone.service.BankService;

@RestController
@RequestMapping("/bank")
public class BankController {
	
	@Autowired
	BankService bankServ;
	
	@PostMapping
    public BankAccount createBankAccount(@RequestBody BankAccount bankAccount) {
        return bankServ.saveBankAccount(bankAccount);
    }
	
    @GetMapping
    public List<BankAccount> getAllBankAccounts() {
        return bankServ.getAllBankAccount();
    }

    @GetMapping("/{id}")
    public Optional<BankAccount> getBankAccountById(@PathVariable Integer id) {
        return bankServ.getBankAccountById(id);
    }

    @PutMapping("/{id}")
    public BankAccount updateBankAccountById(@PathVariable Integer id, @RequestBody BankAccount bankAccount) {
        return bankServ.updateBankAccountById(id, bankAccount);
    }

    @DeleteMapping("/{id}")
    public void deleteBankAccount(@PathVariable Integer id) {
    	bankServ.deleteBankAccountById(id);
    }
}
	
