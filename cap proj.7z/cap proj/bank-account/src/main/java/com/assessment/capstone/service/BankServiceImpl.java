package com.assessment.capstone.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assessment.capstone.entity.BankAccount;
import com.assessment.capstone.repo.BankRepo;
@Service
public class BankServiceImpl implements BankService{
	
	@Autowired
	BankRepo bankRepo;

	@Override
	public BankAccount saveBankAccount(BankAccount bankAccount) {
		BankAccount saveBankAccount = bankRepo.save(bankAccount);
		return saveBankAccount;
	}

	@Override
	public List<BankAccount> getAllBankAccount() {
		List<BankAccount> findAllBankAccount = bankRepo.findAll();
		return findAllBankAccount;
	}

	@Override
	public Optional<BankAccount> getBankAccountById(int id) {
		Optional<BankAccount> findByBankAccountId = bankRepo.findById(id);
		return findByBankAccountId;
	}

	@Override
	public BankAccount updateBankAccountById(int id, BankAccount bankAccount) {

	    BankAccount existingBankAccount = bankRepo.findById(id).orElse(null);

	    if (existingBankAccount != null) {
	        existingBankAccount.setAccountNumber(bankAccount.getAccountNumber());
	        existingBankAccount.setAccountType(bankAccount.getAccountType());

	        return bankRepo.save(existingBankAccount);
	    }

	    return null;
	}

	@Override
	public void deleteBankAccountById(int id) {
		bankRepo.deleteById(id);
	}

	@Override
	public Optional<BankAccount> findByUserId(int userId) {
		Optional<BankAccount> findByUserId = bankRepo.findById(userId);
		return findByUserId;
	}

}
