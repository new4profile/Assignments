package com.assessment.capstone.service;

import java.util.List;
import java.util.Optional;

import com.assessment.capstone.entity.BankAccount;

public interface BankService {
	BankAccount saveBankAccount(BankAccount bankAccount);
    List<BankAccount> getAllBankAccount();
    Optional<BankAccount> getBankAccountById(int id);
    BankAccount updateBankAccountById(int id, BankAccount bankAccount);
    void deleteBankAccountById(int id);
    
    Optional<BankAccount> findByUserId(int userId);
	
}
