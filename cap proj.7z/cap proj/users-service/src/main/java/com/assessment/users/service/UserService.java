package com.assessment.users.service;

import java.util.List;
import java.util.Optional;

import com.assessment.users.entity.User;



public interface UserService {
	User saveUser(User user);
    List<User> getAllUsers();
    Optional<User> getUserById(int id);
    User updateUserById(int id, User user);
    void deleteUserById(int id);
}
