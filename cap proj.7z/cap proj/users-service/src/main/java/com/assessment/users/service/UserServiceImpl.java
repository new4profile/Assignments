package com.assessment.users.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.assessment.users.entity.User;
import com.assessment.users.repo.UserRepo;
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo userRepo;
	
//	@Autowired
//	private RestTemplate restTemplate;
	
	@Override
	public User saveUser(User user) {
		User saveUser = userRepo.save(user);
		
        int userId = saveUser.getId();
        return saveUser;
	}
	

	@Override
	public List<User> getAllUsers() {
		List<User> findAllUser = userRepo.findAll();
		return findAllUser;
	}

	@Override
	public Optional<User> getUserById(int id) {
		Optional<User> findUserById = userRepo.findById(id);
		return findUserById;
	}

	@Override
	public User updateUserById(int id, User user) {
		Optional<User> existUser = userRepo.findById(id);
		if(existUser.isPresent()) {
			User updateUser = existUser.get();
			updateUser.setName(user.getName());
			updateUser.setAddress(user.getAddress());
			return userRepo.save(updateUser);
		}
		return null;
	}

	@Override
	public void deleteUserById(int id) {
		userRepo.deleteById(id);
	}

}

