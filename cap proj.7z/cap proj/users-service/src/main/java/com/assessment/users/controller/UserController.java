package com.assessment.users.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assessment.users.entity.User;
import com.assessment.users.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	UserService userServ;
	
//	@Autowired
//	BankService bankService;
	
	@GetMapping("/{id}")
	public Optional<User> getById(@PathVariable int id) {
		return userServ.getUserById(id);
	}
	@PostMapping
	public void saveUser(@RequestBody User user) {
		userServ.saveUser(user);
	}
	@GetMapping
	public List<User> findAll() {
		return userServ.getAllUsers();
		}
	@PutMapping("/{id}")
	public void update(@PathVariable int id,@RequestBody User user) {
		userServ.updateUserById(id, user);
	}
	@DeleteMapping("/{id}")
	public void deleteById(@PathVariable int id) {
		userServ.deleteUserById(id);
	}
	
}
