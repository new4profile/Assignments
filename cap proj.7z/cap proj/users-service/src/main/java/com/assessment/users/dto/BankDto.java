package com.assessment.users.dto;

public class BankDto {
	private int id;
    private String accountNumber;
    private String accountType;
    private int userId;
	
	
}
