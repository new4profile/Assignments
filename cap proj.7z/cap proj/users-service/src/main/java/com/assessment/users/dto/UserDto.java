package com.assessment.users.dto;

import java.util.List;

public class UserDto {
	
	private int id;
    private String name;
    private String address;
    private List<BankDto> listBankAccounts;
	

	
}
