package com.assignment.service;



import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.assignment.entity.Employee;

@Service
public class EmployeeService {

    private List<Employee> employees = new ArrayList<>();

    // Adding some mock data for employees
    public EmployeeService() {
        employees.add(new Employee(1, "John", "Developer", "New York", "IT"));
        employees.add(new Employee(2, "Jane", "Manager", "London", "HR"));
        employees.add(new Employee(3, "Sam", "Designer", "San Francisco", "Design"));
    }

    // Get all employees
    public List<Employee> getAllEmployees() {
        return employees;
    }

    // Get employee by ID
    public Employee getEmployeeById(int id) {
        return employees.stream().filter(e -> e.getId() == id).findFirst().orElse(null);
    }

    // Add a new employee
    public Employee addEmployee(Employee employee) {
        employees.add(employee);
        return employee;
    }
}
