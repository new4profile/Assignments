package com.assignment.entity;





public class Employee {
    private int id;
    private String name;
    private String designation;
    private String location;
    private String department;

    // Constructor
    public Employee(int id, String name, String designation, String location, String department) {
        this.id = id;
        this.name = name;
        this.designation = designation;
        this.location = location;
        this.department = department;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
}
